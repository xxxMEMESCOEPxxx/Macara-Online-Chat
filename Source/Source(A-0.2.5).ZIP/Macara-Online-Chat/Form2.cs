﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using ChatClient.Properties;
using System.Diagnostics;

namespace ChatClient
{
    public partial class Form2 : Form
    {

        //bool setvalue;
        //const int prevbrate = Int32.Parse(Settings.Default.connbaudrate);
        private static readonly string StartupKey = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run";
        private static readonly string StartupValue = "ChatClient";
        public bool startvc = false;
        public Form2()
        {
            
            InitializeComponent();
            
        }
        public override System.Drawing.Color BackColor { get; set; }
        public void Form2_Load(object sender, EventArgs e)
        {

            //textBox1.Text = Settings.Default["isStartupApp"].ToString();
            if(Settings.Default.isDarkMode == true)
            {
                tabPage1.BackColor = SystemColors.ControlDarkDark;
                tabPage1.ForeColor = Color.White;
                button3.ForeColor = Color.Black;
                button2.ForeColor = Color.Black;

                tabPage2.BackColor = SystemColors.ControlDarkDark;
                tabPage2.ForeColor = Color.White;
                tabPage3.BackColor = SystemColors.ControlDarkDark;
                tabPage3.ForeColor = Color.White;
                
                this.BackColor = SystemColors.ControlDarkDark;
            }
            else
            {
                tabPage1.BackColor = Color.White;
                tabPage1.ForeColor = Color.Black;
                this.BackColor = SystemColors.Control;
            }
            

        }

       







        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox2.Checked == true){
                //setvalue = false;
                RegistryKey reg = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                reg.SetValue("chatclient.exe", 0);
                //checkBox2.Checked = setvalue;
            }
            if(checkBox2.Checked == false)
            {
                //setvalue = true;
                RegistryKey reg = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                reg.SetValue("chatclient.exe", Application.ExecutablePath.ToString());
                //checkBox2.Checked = setvalue;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Save();
           
            //Settings.Default["isStartupApp"] = setvalue;
            this.Close();
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            
           
        }

        private void setRate_TextChanged(object sender, EventArgs e)
        {
            currentrate.Text = Settings.Default.connbaudrate;
            //comboBox1.Text = comboBox1.SelectedValue.ToString();
            //int x = int.Parse(setRate.Text = Properties.Settings.Default.testrate.ToString());
            if (setRate.Text != null)
            {

                Settings.Default.connbaudrate = setRate.Text;
                Settings.Default.Save();
            }
            else
            { //Value is null }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("No update(s) availiable", "No update(s) availiable", 0, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string path = @"serhist.hst";
            DialogResult result = MessageBox.Show("Are you sure you want to clear your history?         THIS CANNOT BE UNDONE!", "Clear History?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                try
                {
                    if (File.Exists(path))
                    {
                        File.WriteAllText(path, String.Empty);
                        MessageBox.Show("History Cleared Successfully!", "Clear Successfull", 0, MessageBoxIcon.Information);
                    }
                    else
                    {
                        DialogResult errresult = MessageBox.Show("Failed to clear History! Would you like to clear it manually?", "Clear Failed", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                        if (errresult == DialogResult.Yes)
                        {
                            if (File.Exists(path))
                            {
                                Process.Start(path);
                            }
                        }
                        else
                        {

                        }
                    }
                    
                }
                catch
                {
                    DialogResult errresult = MessageBox.Show("Failed to clear History! Would you like to clear it manually?", "Clear Failed", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                    if(errresult == DialogResult.Yes)
                    {
                        if (File.Exists(path))
                        {
                            Process.Start("explorer.exe", path);
                        }
                    }
                    else
                    {

                    }
                }
                
                //listBox1.Items.Clear();
                //listBox1.Items.Add("History Cleared.");
            }
            else
            {

            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == true)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.startvc = true;
                Settings.Default.Save();
                //comboBox1.Text = comboBox1.SelectedValue.ToString();
                //int x = int.Parse(setRate.Text = Properties.Settings.Default.testrate.ToString());
                startvc = true;
            }
            if (checkBox4.Checked == false)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.startvc = false;
                Settings.Default.Save();
                startvc = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.censorchat = true;
                Settings.Default.Save();
                //comboBox1.Text = comboBox1.SelectedValue.ToString();
                //int x = int.Parse(setRate.Text = Properties.Settings.Default.testrate.ToString());
                //startvc = true;
            }
            if (checkBox1.Checked == false)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.censorchat = false;
                Settings.Default.Save();
                //startvc = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == true)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.autoConnect = true;
                Settings.Default.Save();
                //comboBox1.Text = comboBox1.SelectedValue.ToString();
                //int x = int.Parse(setRate.Text = Properties.Settings.Default.testrate.ToString());
                //startvc = true;
            }
            if (checkBox5.Checked == false)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.autoConnect = false;
                Settings.Default.Save();
                //startvc = false;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == true)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.isDarkMode = true;
                Settings.Default.Save();
                if (MessageBox.Show("A restart of this program is required to apply these changes. Do you want to restart now?", "App restart required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Restart();
                    Environment.Exit(0);
                }
                else
                {
                    // user clicked no
                }

                


                //comboBox1.Text = comboBox1.SelectedValue.ToString();
                //int x = int.Parse(setRate.Text = Properties.Settings.Default.testrate.ToString());
                //startvc = true;
            }
            if (checkBox6.Checked == false)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.isDarkMode = false;
                Settings.Default.Save();
                if (MessageBox.Show("A restart of this program is required to apply these changes. Do you want to restart now?", "App restart required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Restart();
                    Environment.Exit(0);
                }
                else
                {
                    // user clicked no
                }
                //startvc = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to reset your settings? THIS CANNOT BE UNDONE!", "Reset Settings", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Settings.Default.Reset();
                Settings.Default.censorchat = true;
                if (MessageBox.Show("A restart of this program is required to apply these changes. Do you want to restart now?", "App restart required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Restart();
                    Environment.Exit(0);
                }
                else
                {
                    // user clicked no
                }
            }
            else
            {
                // user clicked no
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == true)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.HistRec = true;
                Settings.Default.Save();
                if (MessageBox.Show("A restart of this program is required to apply these changes. Do you want to restart now?", "App restart required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Restart();
                    Environment.Exit(0);
                }
                else
                {
                    // user clicked no
                }




                //comboBox1.Text = comboBox1.SelectedValue.ToString();
                //int x = int.Parse(setRate.Text = Properties.Settings.Default.testrate.ToString());
                //startvc = true;
            }
            if (checkBox7.Checked == false)
            {
                //startvc = Settings.Default.startvc;
                Settings.Default.HistRec = false;
                Settings.Default.Save();
                if (MessageBox.Show("A restart of this program is required to apply these changes. Do you want to restart now?", "App restart required", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Application.Restart();
                    Environment.Exit(0);
                }
                else
                {
                    // user clicked no
                }
                //startvc = false;
            }
        }

        /*private void button3_Click(object sender, EventArgs e)
        {
            string path = @".\serhist.hst"; 
            //File.Close();
            File.WriteAllLines(path, null);
        }*/

    }
}
