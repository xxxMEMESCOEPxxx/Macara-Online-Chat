﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatClient
{
    public partial class Form5 : Form
    {
        string path = @"serhist.hst";
        private string[] lines;
        private int index = 0;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
           
            try
            {
                
                //MessageBox.Show("nO U");
                //TextReader txtSread2 = new StreamReader("serhist.hst");
                /*while(true)
                {
                    string placeholder = txtSread2.ReadLine() + Environment.NewLine + Environment.NewLine;
                    //listBox1.Items.Add() += placeholder; 
                    listBox1.Items.Add(placeholder);
                    txtSread2.Close();
                    lines = lines ?? File.ReadAllLines("serhist.hst");

                    // sanity check 
                    if (index < lines.Length)
                    {
                        //string placeholder1 = txtSread2.ReadLine() + Environment.NewLine + Environment.NewLine;
                        //placeholder += Environment.NewLine;
                        listBox1.Items.Add(placeholder);
                        //listBox1.Items.Add(placeholder);
                        //listBox1.Items.Add(index);
                    }
                       


                }*/
                foreach (string line1 in File.ReadAllLines(path))
                {
                    listBox1.Items.Add(line1);
                }

                int counter = 0;
                string line;

                // Read the file and display it line by line.  
                /*System.IO.StreamReader file = new System.IO.StreamReader(path);
                
                while ((line = file.ReadLine()) != null)
                {
                    
                    //listBox1.Items.Add(line);
                    //listBox1.Items.Add("\n");

                    //System.Console.WriteLine(line);
                    counter++;
                    
                }

                file.Close();*/

            }
            catch
            {
                //file.Close();
                //MessageBox.Show("Unable to find file 'serhist.hst'!", "FILE NOT FOUND", 0, MessageBoxIcon.Error);
            }
           
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /*private void clearhist_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to clear your history? THIS CANNOT BE UNDONE!", "Clear History?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                File.WriteAllText(path, String.Empty);
                listBox1.Items.Clear();
                listBox1.Items.Add("History Cleared.");
            }
            else
            {

            }
            //System.IO.StreamReader file1 = new System.IO.StreamReader(path);
            
            //file1.Close();
        }*/
    }
}
